REPARTIR CORREOS - SAMSUNG EMAIL + WHATSAPP BUSINESS

Esta es la versión 2 del proyecto Android.

FUNCIONAMIENTO
1. En Samsung Email, abre el correo que quieras compartir.
2. Pulsa Compartir y selecciona "Repartir por WhatsApp Business" (el nombre puede aparecer abreviado).
3. En la aplicación, pulsa el botón del empleado.
4. Si el correo solo contiene texto, se abre directamente el chat de ese empleado en WhatsApp Business con el texto preparado.
5. Si contiene archivos adjuntos, Android los comparte con WhatsApp Business. Por una limitación de Android/WhatsApp, tendrás que seleccionar el chat del empleado dentro de WhatsApp Business.

EMPLEADOS
Los diez nombres y teléfonos iniciales son ficticios. Pulsa "Editar los 10 empleados" para sustituirlos.
Los teléfonos deben incluir el prefijo internacional, sin el signo +. Para España: 34 seguido del número.

IMPORTANTE
- No reenvía correos automáticamente.
- No accede por su cuenta al buzón IMAP ni lee otros correos.
- Solo recibe el contenido que el usuario comparte manualmente desde Samsung Email.
- WhatsApp Business debe estar instalado.
- Los adjuntos dependen de lo que Samsung Email permita compartir y de los formatos aceptados por WhatsApp Business.

INSTALACIÓN / COMPILACIÓN
Este ZIP contiene el proyecto fuente para abrirlo con Android Studio.
No es un APK instalable directamente. En Android Studio: File > Open, selecciona la carpeta
WhatsAppRepartidor_Samsung_WhatsAppBusiness, espera la sincronización de Gradle y usa
Build > Build Bundle(s) / APK(s) > Build APK(s).
