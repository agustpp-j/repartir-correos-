package com.example.whatsapprepartidor

import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.ViewGroup
import android.widget.*
import java.net.URLEncoder

class MainActivity : Activity() {
    data class Employee(val name: String, val phone: String)

    private val prefs by lazy { getSharedPreferences("employees", MODE_PRIVATE) }
    private lateinit var employeeList: LinearLayout
    private lateinit var sharedInfo: TextView
    private var mailSubject = ""
    private var mailText = ""
    private var attachments = ArrayList<Uri>()
    private var attachmentMime = "*/*"

    private val defaults = listOf(
        Employee("Juan García", "34600000001"),
        Employee("Pedro López", "34600000002"),
        Employee("Antonio Ruiz", "34600000003"),
        Employee("José Martín", "34600000004"),
        Employee("Miguel Sánchez", "34600000005"),
        Employee("Carlos Pérez", "34600000006"),
        Employee("David Gómez", "34600000007"),
        Employee("Luis Navarro", "34600000008"),
        Employee("Manuel Torres", "34600000009"),
        Employee("Francisco Díaz", "34600000010")
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        receiveSharedEmail(intent)
        buildScreen()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        receiveSharedEmail(intent)
        if (::sharedInfo.isInitialized) updateSharedInfo()
    }

    private fun employee(i: Int): Employee = Employee(
        prefs.getString("name$i", defaults[i].name) ?: defaults[i].name,
        prefs.getString("phone$i", defaults[i].phone) ?: defaults[i].phone
    )

    private fun receiveSharedEmail(source: Intent?) {
        if (source == null) return
        mailSubject = source.getStringExtra(Intent.EXTRA_SUBJECT).orEmpty()
        mailText = source.getCharSequenceExtra(Intent.EXTRA_TEXT)?.toString().orEmpty()
        attachments.clear()

        val stream = source.getParcelableExtra<Uri>(Intent.EXTRA_STREAM)
        if (stream != null) attachments.add(stream)

        val many = source.getParcelableArrayListExtra<Uri>(Intent.EXTRA_STREAM)
        if (!many.isNullOrEmpty()) {
            attachments.clear()
            attachments.addAll(many)
        }

        val clip: ClipData? = source.clipData
        if (attachments.isEmpty() && clip != null) {
            for (i in 0 until clip.itemCount) {
                clip.getItemAt(i).uri?.let { attachments.add(it) }
            }
        }

        attachmentMime = source.type ?: "*/*"
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 22, 22, 22)
        }

        val title = TextView(this).apply {
            text = "REPARTIR CORREOS"
            textSize = 24f
            setPadding(0, 0, 0, 10)
        }
        root.addView(title)

        sharedInfo = TextView(this).apply {
            textSize = 15f
            setPadding(0, 0, 0, 12)
        }
        root.addView(sharedInfo)
        updateSharedInfo()

        val edit = Button(this).apply {
            text = "⚙  EDITAR LOS 10 EMPLEADOS"
            setOnClickListener { editEmployees() }
        }
        root.addView(edit)

        val hint = TextView(this).apply {
            text = "Elige el empleado al que quieres enviar el correo:"
            textSize = 16f
            setPadding(0, 14, 0, 8)
        }
        root.addView(hint)

        val scroll = ScrollView(this)
        employeeList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(employeeList)
        root.addView(scroll, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f
        ))

        setContentView(root)
        refreshEmployees()
    }

    private fun updateSharedInfo() {
        if (!::sharedInfo.isInitialized) return
        val hasMail = mailSubject.isNotBlank() || mailText.isNotBlank() || attachments.isNotEmpty()
        sharedInfo.text = if (!hasMail) {
            "Abre Samsung Email, selecciona un correo y pulsa Compartir para enviarlo aquí."
        } else {
            val subject = if (mailSubject.isBlank()) "Correo recibido" else mailSubject
            "Correo seleccionado: $subject\nAdjuntos: ${attachments.size}"
        }
    }

    private fun refreshEmployees() {
        employeeList.removeAllViews()
        for (i in 0 until 10) {
            val e = employee(i)
            val button = Button(this).apply {
                text = "ENVIAR A  ${e.name}"
                textSize = 16f
                setOnClickListener { sendToBusiness(e) }
            }
            employeeList.addView(button, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ))
        }
    }

    private fun sendToBusiness(e: Employee) {
        val phone = e.phone.filter { it.isDigit() }
        if (phone.length < 8) {
            Toast.makeText(this, "Revisa el teléfono de ${e.name}", Toast.LENGTH_LONG).show()
            return
        }

        val message = buildString {
            if (mailSubject.isNotBlank()) append("Asunto: ").append(mailSubject).append("\n\n")
            if (mailText.isNotBlank()) append(mailText)
        }.trim()

        if (attachments.isEmpty()) {
            // Para texto sin adjuntos podemos abrir directamente el chat del empleado.
            val url = "https://wa.me/$phone?text=" + URLEncoder.encode(message, "UTF-8")
            try {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                    setPackage("com.whatsapp.w4b")
                })
            } catch (_: Exception) {
                Toast.makeText(this, "No se ha podido abrir WhatsApp Business. Comprueba que está instalado.", Toast.LENGTH_LONG).show()
            }
            return
        }

        // WhatsApp Business recibe los archivos; por seguridad Android deja que el usuario elija el chat.
        AlertDialog.Builder(this)
            .setTitle("Enviar archivos a ${e.name}")
            .setMessage("Se abrirá WhatsApp Business con el correo y sus archivos. Por una limitación de Android/WhatsApp, tendrás que seleccionar el chat de ${e.name} dentro de WhatsApp Business.")
            .setNegativeButton("Cancelar", null)
            .setPositiveButton("Continuar") { _, _ -> shareAttachments(message) }
            .show()
    }

    private fun shareAttachments(message: String) {
        try {
            val send = if (attachments.size == 1) {
                Intent(Intent.ACTION_SEND).apply {
                    type = attachmentMime
                    putExtra(Intent.EXTRA_STREAM, attachments[0])
                }
            } else {
                Intent(Intent.ACTION_SEND_MULTIPLE).apply {
                    type = attachmentMime
                    putParcelableArrayListExtra(Intent.EXTRA_STREAM, attachments)
                }
            }
            if (message.isNotBlank()) send.putExtra(Intent.EXTRA_TEXT, message)
            send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            send.clipData = ClipData.newUri(contentResolver, "Adjuntos del correo", attachments[0])
            for (uri in attachments.drop(1)) {
                send.clipData?.addItem(ClipData.Item(uri))
            }
            send.setPackage("com.whatsapp.w4b")
            startActivity(send)
        } catch (_: Exception) {
            Toast.makeText(this, "No se pudieron compartir los archivos con WhatsApp Business.", Toast.LENGTH_LONG).show()
        }
    }

    private fun editEmployees() {
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 8, 16, 8)
        }
        val scroll = ScrollView(this).apply { addView(content) }
        val names = Array(10) { EditText(this) }
        val phones = Array(10) { EditText(this) }

        for (i in 0 until 10) {
            val e = employee(i)
            val label = TextView(this).apply { text = "Empleado ${i + 1}" }
            content.addView(label)
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            names[i].setText(e.name)
            names[i].hint = "Nombre"
            phones[i].setText(e.phone)
            phones[i].hint = "Prefijo + teléfono (ej. 346XXXXXXXX)"
            phones[i].inputType = 3
            row.addView(names[i], LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.2f))
            row.addView(phones[i], LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            content.addView(row)
        }

        AlertDialog.Builder(this)
            .setTitle("Editar empleados")
            .setView(scroll)
            .setPositiveButton("Guardar") { _, _ ->
                val editor = prefs.edit()
                for (i in 0 until 10) {
                    editor.putString("name$i", names[i].text.toString().trim())
                    editor.putString("phone$i", phones[i].text.toString().filter { it.isDigit() })
                }
                editor.apply()
                refreshEmployees()
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }
}
